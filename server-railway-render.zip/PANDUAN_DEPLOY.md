# PANDUAN DEPLOY — Inventaris Komputer BTN KC Padang & KCP

Susunan akhir:

```
[Netlify]  tampilan aplikasi  ──►  [Railway / Render]  server (API)  ──►  [MongoDB Atlas]  database
netlify-site.zip                   server-railway-render.zip
```

Kerjakan **berurutan**: Atlas → Server → Netlify → daftarkan alamat Netlify ke server.

> Contoh alamat di panduan ini (`btninventaris...`) hanya contoh. Pakai alamat yang benar-benar diberikan Railway/Render/Netlify kepada Anda.

---

## LANGKAH 1 — Database di MongoDB Atlas (gratis)

1. Buka https://www.mongodb.com/cloud/atlas/register → daftar / login.
2. **Create** → pilih paket **M0 (Free)** → pilih region terdekat (mis. Singapore) → **Create Deployment**.
3. Buat **Database User**: isi username & password (catat!). Hindari karakter `@ : / ? # %` di password agar tidak perlu di-encode.
4. Menu **Network Access** → **Add IP Address** → **Allow Access from Anywhere** (`0.0.0.0/0`) → Confirm.
   (Railway/Render tidak punya IP tetap, jadi ini wajib.)
5. Menu **Database / Clusters** → **Connect** → **Drivers** → salin connection string, contoh:
   ```
   mongodb+srv://adminbtn:PasswordAnda@cluster0.ab12c.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
   ```
   Ganti `<db_password>` dengan password user tadi. Inilah nilai **MONGO_URL**.

---

## LANGKAH 2A — Server di Railway (jalur utama)

1. Ekstrak `server-railway-render.zip` di komputer Anda.
2. Cara paling mudah: unggah isi folder itu ke repository GitHub baru (mis. `btninventaris-server`), lalu:
   Railway (https://railway.com) → **New Project** → **Deploy from GitHub repo** → pilih repo tersebut.
   *Alternatif tanpa GitHub:* install Railway CLI, buka folder hasil ekstrak, jalankan `railway login`, `railway init`, `railway up`.
3. Buka service → tab **Variables** → tambahkan:

   | Nama | Contoh isi |
   |---|---|
   | `MONGO_URL` | connection string dari Langkah 1 |
   | `DB_NAME` | `btninventaris` |
   | `JWT_SECRET` | string acak panjang, mis. hasil https://www.random.org/strings/ atau `python -c "import secrets;print(secrets.token_hex(32))"` |
   | `SEED_USERS` | `ITOD-SDD.Radi\|Radi\|PasswordBaru1,ITOD-SDD.Defriandi\|Defriandi\|PasswordBaru2` |
   | `CORS_ORIGINS` | sementara isi `*` — nanti diganti alamat Netlify (Langkah 4) |

   - `SEED_USERS` = daftar akun **admin** awal, format `username|Nama|password`, dipisah koma. Akun hanya dibuat jika belum ada; password akun yang sudah ada tidak akan ditimpa. Akun lain dibuat dari menu **Kelola Akun** di aplikasi.
4. Tab **Settings** → **Networking** → **Generate Domain**. Anda mendapat alamat seperti `https://btninventaris.up.railway.app`.
5. Tes: buka `https://ALAMAT-SERVER/api/health` di browser → harus tampil `{"status":"ok"}`.
   Jika error, lihat tab **Deployments → View Logs** (biasanya `MONGO_URL` salah atau Network Access Atlas belum dibuka).

File pendukung di paket: `railway.json` (perintah start + health check), `Procfile`, `.python-version` (Python 3.11), `requirements.txt`.

## LANGKAH 2B — Server di Render (alternatif)

1. Unggah isi `server-railway-render.zip` ke repository GitHub.
2. Render (https://render.com) → **New** → **Blueprint** → pilih repo (Render membaca `render.yaml` otomatis).
   *Atau* **New → Web Service** → pilih repo, lalu isi:
   - Runtime: **Python**
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn server:app --host 0.0.0.0 --port $PORT`
   - Health Check Path: `/api/health`
3. **Environment** → isi variabel yang sama seperti tabel Railway di atas (`MONGO_URL`, `DB_NAME`, `JWT_SECRET`, `SEED_USERS`, `CORS_ORIGINS`), plus `PYTHON_VERSION` = `3.11.9`.
4. Alamat server berbentuk `https://btninventaris.onrender.com`. Tes `.../api/health`.
5. Catatan: paket gratis Render "tertidur" setelah ±15 menit tidak dipakai; akses pertama bisa lambat 30–60 detik.

---

## LANGKAH 3 — Tampilan di Netlify

1. Ekstrak `netlify-site.zip`. Buka file **`config.js`** dengan Notepad:
   ```js
   window.APP_CONFIG = {
     BACKEND_URL: "https://btninventaris.up.railway.app"
   };
   ```
   Ganti alamat dengan alamat server Anda dari Langkah 2 (**tanpa** `/api`, **tanpa** `/` di akhir). Simpan.
2. Pilih **semua isi folder** (index.html, config.js, _redirects, _headers, static, dll.) → klik kanan → *Kirim ke → Folder terkompresi (zip)*.
   Penting: `index.html` harus berada di **paling atas** ZIP, bukan di dalam subfolder.
   *Lebih mudah:* seret **folder hasil ekstrak** langsung ke Netlify (tidak perlu di-ZIP ulang).
3. Netlify → **Add new project → Deploy manually** → seret ZIP/folder ke kotak **"Upload your project files"**.
4. Netlify memberi alamat seperti `https://btninventaris.netlify.app` (bisa diganti di **Project configuration → Change project name**).
5. Jika alamat server berubah di kemudian hari: ubah `config.js` → unggah ulang di tab **Deploys** (tidak perlu build ulang).

File `_redirects` membuat halaman `/login` dan `/akun` tetap terbuka saat di-refresh.

---

## LANGKAH 4 — Hubungkan Netlify ke server (wajib, demi keamanan)

1. Kembali ke Railway/Render → Variables → ubah `CORS_ORIGINS` menjadi alamat Netlify Anda, mis.:
   ```
   https://btninventaris.netlify.app
   ```
   Lebih dari satu alamat dipisah koma: `https://btninventaris.netlify.app,https://inventaris.domainanda.co.id`
2. Simpan → server akan restart otomatis (Render: klik **Manual Deploy** jika tidak otomatis).

---

## LANGKAH 5 — Pindahkan data lama (opsional)

Pilih salah satu:

- **Lewat aplikasi (paling mudah):** di aplikasi lama → **Export → Ke Excel** (atau pakai file `data-komputer.xlsx` dari tautan unduhan). Di aplikasi baru → login → **Import Excel** → pilih file tersebut.
- **Lewat file database:** `project-backup.zip` berisi `database-export/computers.json`. Jalankan di komputer yang punya MongoDB Database Tools:
  ```
  mongoimport --uri "MONGO_URL_ANDA" --db btninventaris --collection computers --file computers.json
  ```
  Atau di Atlas: **Data Explorer / Collections** → buat database `btninventaris`, collection `computers` → **Insert Document → Import JSON**.

Akun petugas **tidak** dipindahkan (password tidak disimpan di backup). Akun admin dibuat dari `SEED_USERS`, akun lain dibuat ulang lewat **Kelola Akun**.

---

## LANGKAH 6 — Cek semuanya berjalan

1. Buka alamat Netlify → halaman login tampil, chip akun cepat muncul (artinya tampilan sudah terhubung ke server).
2. Login dengan akun dari `SEED_USERS` → muncul "Selamat datang, …".
3. **Tambah Komputer** → simpan → data muncul di tabel.
4. **Export → Ke PDF** → pratinjau → **Unduh PDF**.
5. **Export → Ke Excel** → file .xlsx terunduh.
6. Refresh halaman di `/akun` → halaman tetap terbuka (tidak "Page not found").

## Jika ada masalah

| Gejala | Penyebab umum & solusi |
|---|---|
| Login gagal "Network Error" / chip akun tidak muncul | `config.js` salah alamat, atau `CORS_ORIGINS` belum berisi alamat Netlify (persis, diawali `https://`, tanpa `/` di akhir) |
| `/api/health` error / server crash | `MONGO_URL` salah, password Atlas salah, atau Network Access belum `0.0.0.0/0` |
| "Username atau password salah" | Akun dibuat dari `SEED_USERS` saat server pertama kali start; cek ejaan. Mengubah password di `SEED_USERS` setelahnya tidak mengubah akun yang sudah ada — gunakan menu Kelola Akun → Reset Password |
| Akses pertama sangat lambat (Render) | Server gratis sedang "bangun", tunggu ±1 menit |
| Refresh halaman → "Page not found" | File `_redirects` tidak ikut terunggah; pastikan berada sejajar dengan `index.html` |

## Keamanan
- Jangan pernah memasukkan file `.env` berisi password ke GitHub publik. Semua nilai rahasia diisi di dashboard Railway/Render.
- Ganti `JWT_SECRET` dengan nilai acak baru (jangan pakai contoh).
- Setelah aplikasi live, minta penghapusan folder unduhan backup di workspace Emergent.
