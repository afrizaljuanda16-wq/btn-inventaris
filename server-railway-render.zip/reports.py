from io import BytesIO
from pathlib import Path
from datetime import datetime, timezone, timedelta

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether

LOCATIONS = ["KC Padang", "KCP Bypass", "KCP Sutomo", "KCP Ulak Karang", "KCP Pariaman", "KCP Bukittinggi", "KCP Payakumbuh"]
WIB = timezone(timedelta(hours=7))
ASSETS = Path(__file__).parent / "assets"
NAVY = colors.HexColor("#0A3D7A")
BLUE = colors.HexColor("#1257A3")
GOLD = colors.HexColor("#E8A824")
GRID = colors.HexColor("#C9D3E0")
LIGHT = colors.HexColor("#F2F5F9")
MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
COLUMNS = [("Lokasi", "location"), ("Nama User", "user_name"), ("Divisi", "division"), ("Hostname", "hostname"),
           ("IP Address", "ip"), ("MAC Address", "mac"), ("SN Komputer", "sn"), ("Keterangan", "note"), ("Diinput Oleh", "created_by")]


def fmt_wib(dt: datetime):
    return f"{dt.day} {MONTHS[dt.month - 1]} {dt.year}, {dt.strftime('%H:%M')} WIB"


def grouped(items):
    return [(loc, [c for c in items if c.location == loc]) for loc in LOCATIONS if any(c.location == loc for c in items)]


def _p(text, size=8, bold=False, mono=False, color=colors.black, align=0, italic=False):
    font = "Courier" if mono else ("Helvetica-Bold" if bold else ("Helvetica-Oblique" if italic else "Helvetica"))
    style = ParagraphStyle("x", fontName=font, fontSize=size, leading=size * 1.25, textColor=color, alignment=align)
    return Paragraph(str(text).replace("&", "&amp;").replace("<", "&lt;"), style)


def build_pdf(items, opts, user):
    now = datetime.now(WIB)
    buf = BytesIO()
    page_w, page_h = landscape(A4)
    margin = 15 * mm
    width = page_w - 2 * margin
    pages = [0]

    def decorate(canv, doc):
        pages[0] = doc.page
        top = page_h - 12 * mm
        canv.drawImage(str(ASSETS / "sdd.png"), margin, top - 16 * mm, width=36 * mm, height=16 * mm, mask="auto", preserveAspectRatio=True, anchor="w")
        canv.drawImage(str(ASSETS / "btn.png"), page_w - margin - 26 * mm, top - 16 * mm, width=26 * mm, height=16 * mm, mask="auto", preserveAspectRatio=True, anchor="e")
        canv.setFillColor(NAVY)
        canv.setFont("Helvetica-Bold", 15)
        canv.drawCentredString(page_w / 2, top - 10 * mm, "LAPORAN INVENTARIS PERANGKAT KOMPUTER")
        canv.setFillColor(colors.HexColor("#333333"))
        canv.setFont("Helvetica", 9)
        canv.drawCentredString(page_w / 2, top - 15 * mm, "PT BANK TABUNGAN NEGARA (PERSERO) Tbk - KANTOR CABANG PADANG & KANTOR CABANG PEMBANTU")
        canv.setFont("Helvetica-Oblique", 7.5)
        canv.drawCentredString(page_w / 2, top - 19 * mm, "Dikelola oleh IT Support - PT Swadharma Duta Data")
        canv.setStrokeColor(NAVY)
        canv.setLineWidth(1.6)
        canv.line(margin, top - 22 * mm, page_w - margin, top - 22 * mm)
        canv.setStrokeColor(GOLD)
        canv.setLineWidth(0.8)
        canv.line(margin, top - 23.3 * mm, page_w - margin, top - 23.3 * mm)
        canv.setStrokeColor(GRID)
        canv.setLineWidth(0.5)
        canv.line(margin, 14 * mm, page_w - margin, 14 * mm)
        canv.setFillColor(colors.HexColor("#555555"))
        canv.setFont("Helvetica", 7)
        canv.drawString(margin, 10 * mm, f"Dicetak oleh {user['name']} ({user['username']})  |  {fmt_wib(now)}")
        canv.drawRightString(page_w - margin, 10 * mm, f"Halaman {doc.page}")

    doc = SimpleDocTemplate(buf, pagesize=(page_w, page_h), leftMargin=margin, rightMargin=margin,
                            topMargin=12 * mm + 30 * mm, bottomMargin=20 * mm,
                            title="Laporan Inventaris Perangkat Komputer", author=user["name"])
    story = []

    info = Table([[_p("Tanggal Cetak", 7), _p("Lokasi / Filter", 7), _p("Kata Kunci", 7), _p("Total Perangkat", 7)],
                  [_p(fmt_wib(now), 8.5, True), _p(opts.location or "Semua Lokasi", 8.5, True), _p(opts.q or "-", 8.5, True), _p(f"{len(items)} unit", 8.5, True)]],
                 colWidths=[width / 4] * 4)
    info.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("BOX", (0, 0), (-1, -1), 0.5, GRID),
                              ("LINEAFTER", (0, 0), (-2, -1), 0.5, GRID), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    story += [info, Spacer(1, 8 * mm)]

    widths = [0.04, 0.14, 0.12, 0.13, 0.10, 0.13, 0.12, 0.09, 0.13]
    col_w = [w * width for w in widths]
    groups = grouped(items)
    if not groups:
        story += [_p("Tidak ada data perangkat untuk filter ini.", 9, italic=True, color=colors.grey, align=1), Spacer(1, 8 * mm)]
    for loc, rows in groups:
        head_row = [_p(h, 8, True, color=colors.white) for h in ["No", "Nama User", "Divisi", "Hostname", "IP Address", "MAC Address", "SN Komputer", "Keterangan", "Diinput Oleh"]]
        title = [_p(loc.upper(), 9.5, True, color=colors.white)] + [""] * 7 + [_p(f"{len(rows)} unit", 8, color=colors.white, align=2)]
        data = [title, head_row]
        for i, c in enumerate(rows, 1):
            data.append([_p(i), _p(c.user_name), _p(c.division), _p(c.hostname, 7.5, mono=True), _p(c.ip, 7.5, mono=True),
                         _p(c.mac, 7.5, mono=True), _p(c.sn, 7.5, mono=True), _p(c.note or "-"), _p(c.created_by)])
        t = Table(data, colWidths=col_w, repeatRows=2)
        t.setStyle(TableStyle([
            ("SPAN", (0, 0), (7, 0)), ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BACKGROUND", (0, 1), (-1, 1), BLUE),
            ("GRID", (0, 1), (-1, -1), 0.5, GRID), ("BOX", (0, 0), (-1, -1), 0.5, GRID),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("ROWBACKGROUNDS", (0, 2), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
        ]))
        story += [t, Spacer(1, 6 * mm)]

    if len(groups) > 1:
        sdata = [[_p("Ringkasan per Lokasi", 8, True, color=colors.white), _p("Jumlah", 8, True, color=colors.white)]]
        sdata += [[_p(loc), _p(f"{len(rows)} unit")] for loc, rows in groups]
        sdata.append([_p("TOTAL", 8, True), _p(f"{len(items)} unit", 8, True)])
        s = Table(sdata, colWidths=[65 * mm, 32 * mm], hAlign="LEFT")
        s.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), BLUE), ("GRID", (0, 0), (-1, -1), 0.5, GRID),
                               ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#FDF3DC"))]))
        story += [s, Spacer(1, 6 * mm)]

    def signer(name):
        return f"( {name} )" if name.strip() else "( ........................................ )"

    sign = Table([[_p("Dibuat / Diperiksa oleh,", 9, align=1), "", _p("Mengetahui,", 9, align=1)],
                  [_p("IT Support KC Padang", 9, align=1), "", _p("General Affair (GA)", 9, align=1)],
                  ["", "", ""],
                  [_p(signer(opts.signer_it), 9, bool(opts.signer_it.strip()), align=1), "", _p(signer(opts.signer_ga), 9, bool(opts.signer_ga.strip()), align=1)]],
                 colWidths=[80 * mm, width - 160 * mm, 80 * mm], rowHeights=[None, None, 22 * mm, None])
    story.append(KeepTogether([Spacer(1, 4 * mm), sign]))

    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    return buf.getvalue(), pages[0]


def build_xlsx(items):
    wb = Workbook()
    ws = wb.active
    ws.title = "Inventaris Komputer"
    headers = [h for h, _ in COLUMNS] + ["Tanggal Input"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="0A3D7A")
        cell.alignment = Alignment(vertical="center")
    for c in sorted(items, key=lambda c: (LOCATIONS.index(c.location), c.created_at)):
        created = datetime.fromisoformat(c.created_at).astimezone(WIB).strftime("%Y-%m-%d %H:%M")
        ws.append([getattr(c, key) for _, key in COLUMNS] + [created])
    for i, w in enumerate([18, 24, 20, 20, 16, 20, 20, 26, 22, 18], 1):
        ws.column_dimensions[chr(64 + i)].width = w
    ws.freeze_panes = "A2"
    out = BytesIO()
    wb.save(out)
    return out.getvalue()


def parse_xlsx(content: bytes):
    ws = load_workbook(BytesIO(content), read_only=True, data_only=True).active
    rows = ws.iter_rows(values_only=True)
    header = [str(h or "").strip().lower() for h in next(rows, [])]
    index = {}
    for label, key in COLUMNS:
        if label.lower() in header:
            index[key] = header.index(label.lower())
    missing = [label for label, key in COLUMNS[:7] if key not in index]
    if missing:
        raise ValueError("Kolom tidak ditemukan: " + ", ".join(missing) + ". Gunakan format hasil Export Excel.")
    result = []
    for line, row in enumerate(rows, start=2):
        if not row or all(v in (None, "") for v in row):
            continue
        item = {key: ("" if row[i] is None else str(row[i]).strip()) for key, i in index.items() if i < len(row)}
        loc = next((l for l in LOCATIONS if l.lower() == item.get("location", "").lower()), item.get("location", ""))
        item["location"] = loc
        result.append((line, item))
    return result
