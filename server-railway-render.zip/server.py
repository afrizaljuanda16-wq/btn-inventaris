import os
import re
import logging
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Annotated, Optional

import bcrypt
import jwt
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import FastAPI, APIRouter, Depends, HTTPException, UploadFile, File, Query
from fastapi.responses import Response
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, field_validator
from pymongo import ASCENDING, IndexModel
from starlette.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

from reports import build_pdf, build_xlsx, parse_xlsx, LOCATIONS, WIB  # noqa: E402

client = AsyncIOMotorClient(os.environ['MONGO_URL'])
db = client[os.environ['DB_NAME']]
JWT_SECRET = os.environ['JWT_SECRET']

app = FastAPI()
api = APIRouter(prefix="/api")
bearer = HTTPBearer(auto_error=False)
logger = logging.getLogger(__name__)

PyObjectId = Annotated[str, BeforeValidator(lambda v: str(v) if isinstance(v, ObjectId) else v)]
IP_RE = re.compile(r"^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$")
MAC_RE = re.compile(r"^([0-9A-F]{2}[:-]){5}[0-9A-F]{2}$")


class BaseDocument(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: Optional[PyObjectId] = Field(default=None, alias="_id")

    @classmethod
    def from_mongo(cls, doc):
        return cls.model_validate(doc)

    def to_mongo(self):
        data = self.model_dump(by_alias=True, exclude={"id"})
        if self.id:
            data["_id"] = ObjectId(self.id)
        return data


class User(BaseDocument):
    username: str
    name: str
    password_hash: str
    role: str = "petugas"
    created_at: str = ""


class UserIn(BaseModel):
    username: str
    name: str
    password: str
    role: str = "petugas"

    @field_validator("username")
    @classmethod
    def valid_username(cls, v):
        v = v.strip()
        if not re.match(r"^[A-Za-z0-9._-]{3,40}$", v):
            raise ValueError("Username 3-40 karakter, tanpa spasi (huruf, angka, titik, - atau _)")
        return v

    @field_validator("name")
    @classmethod
    def valid_name(cls, v):
        if not v.strip():
            raise ValueError("Nama wajib diisi")
        return v.strip()

    @field_validator("password")
    @classmethod
    def valid_password(cls, v):
        if len(v) < 4:
            raise ValueError("Password minimal 4 karakter")
        return v

    @field_validator("role")
    @classmethod
    def valid_role(cls, v):
        if v not in ("admin", "petugas"):
            raise ValueError("Peran tidak valid")
        return v


class PasswordIn(BaseModel):
    password: str

    @field_validator("password")
    @classmethod
    def valid_password(cls, v):
        if len(v) < 4:
            raise ValueError("Password minimal 4 karakter")
        return v


class ComputerIn(BaseModel):
    location: str
    user_name: str
    division: str
    hostname: str
    ip: str
    mac: str
    sn: str
    note: str = ""

    @field_validator("user_name", "division", "hostname", "ip", "mac", "sn", mode="before")
    @classmethod
    def required(cls, v):
        v = str(v or "").strip()
        if not v:
            raise ValueError("Kolom wajib diisi")
        return v

    @field_validator("location")
    @classmethod
    def valid_location(cls, v):
        if v not in LOCATIONS:
            raise ValueError("Lokasi tidak valid")
        return v

    @field_validator("ip")
    @classmethod
    def valid_ip(cls, v):
        if not IP_RE.match(v):
            raise ValueError("Format IP Address tidak valid (contoh: 10.14.1.25)")
        return v

    @field_validator("mac")
    @classmethod
    def valid_mac(cls, v):
        v = v.upper()
        if not MAC_RE.match(v):
            raise ValueError("Format MAC Address tidak valid (contoh: 00:1A:2B:3C:4D:5E)")
        return v.replace("-", ":")

    @field_validator("hostname", "sn")
    @classmethod
    def upper(cls, v):
        return v.upper()

    @field_validator("note", mode="before")
    @classmethod
    def strip_note(cls, v):
        return str(v or "").strip()


class Computer(BaseDocument, ComputerIn):
    created_by: str
    created_at: str
    updated_at: str


class LoginIn(BaseModel):
    username: str
    password: str


class PdfIn(BaseModel):
    location: str = ""
    q: str = ""
    signer_it: str = ""
    signer_ga: str = ""


def public_user(u: User):
    return {"username": u.username, "name": u.name, "role": u.role}


def hash_pw(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def username_query(username: str):
    return {"username": {"$regex": f"^{re.escape(username.strip())}$", "$options": "i"}}


async def current_user(cred: HTTPAuthorizationCredentials = Depends(bearer)) -> User:
    if not cred:
        raise HTTPException(401, "Silakan login terlebih dahulu")
    try:
        payload = jwt.decode(cred.credentials, JWT_SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(401, "Sesi berakhir, silakan login kembali")
    doc = await db.users.find_one({"username": payload["sub"]})
    if not doc:
        raise HTTPException(401, "Akun tidak ditemukan")
    return User.from_mongo(doc)


async def admin_user(user: User = Depends(current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(403, "Hanya admin yang dapat mengelola akun")
    return user


@api.get("/users")
async def list_users(admin: User = Depends(admin_user)):
    docs = await db.users.find().sort("username", ASCENDING).to_list(500)
    return [{**public_user(u), "created_at": u.created_at} for u in (User.from_mongo(d) for d in docs)]


@api.post("/users")
async def create_user(body: UserIn, admin: User = Depends(admin_user)):
    if await db.users.find_one(username_query(body.username)):
        raise HTTPException(400, f"Username {body.username} sudah terdaftar")
    u = User(username=body.username, name=body.name, role=body.role, password_hash=hash_pw(body.password),
             created_at=datetime.now(timezone.utc).isoformat())
    await db.users.insert_one(u.to_mongo())
    return {**public_user(u), "created_at": u.created_at}


@api.put("/users/{username}/password")
async def reset_password(username: str, body: PasswordIn, admin: User = Depends(admin_user)):
    res = await db.users.update_one({"username": username}, {"$set": {"password_hash": hash_pw(body.password)}})
    if not res.matched_count:
        raise HTTPException(404, "Akun tidak ditemukan")
    return {"ok": True}


@api.get("/health")
async def health():
    await db.command("ping")
    return {"status": "ok"}


@api.get("/auth/accounts")
async def quick_accounts():
    docs = await db.users.find({}, {"username": 1}).sort("username", ASCENDING).to_list(50)
    return [d["username"] for d in docs]


@api.post("/auth/login")
async def login(body: LoginIn):
    doc = await db.users.find_one(username_query(body.username))
    if not doc or not bcrypt.checkpw(body.password.encode(), doc["password_hash"].encode()):
        raise HTTPException(401, "Username atau password salah")
    user = User.from_mongo(doc)
    token = jwt.encode({"sub": user.username, "exp": datetime.now(timezone.utc) + timedelta(hours=12)}, JWT_SECRET, algorithm="HS256")
    return {"token": token, "user": public_user(user)}


@api.get("/auth/me")
async def me(user: User = Depends(current_user)):
    return public_user(user)


def matches(c: Computer, location: str, q: str) -> bool:
    if location and c.location != location:
        return False
    if q:
        hay = " ".join([c.user_name, c.division, c.hostname, c.ip, c.mac, c.sn, c.note]).lower()
        return q.lower().strip() in hay
    return True


async def list_computers(location: str = "", q: str = ""):
    docs = await db.computers.find().sort("created_at", ASCENDING).to_list(10000)
    return [c for c in (Computer.from_mongo(d) for d in docs) if matches(c, location, q)]


async def check_unique(data: ComputerIn, exclude_id: Optional[str] = None):
    labels = {"hostname": "Hostname", "mac": "MAC Address", "sn": "SN Komputer"}
    for field, label in labels.items():
        query = {field: getattr(data, field)}
        if exclude_id:
            query["_id"] = {"$ne": ObjectId(exclude_id)}
        if await db.computers.find_one(query):
            return f"{label} {getattr(data, field)} sudah terdaftar"
    return None


@api.get("/computers")
async def get_computers(user: User = Depends(current_user)):
    return [c.model_dump() for c in await list_computers()]


@api.post("/computers")
async def create_computer(body: ComputerIn, user: User = Depends(current_user)):
    err = await check_unique(body)
    if err:
        raise HTTPException(400, err)
    now = datetime.now(timezone.utc).isoformat()
    comp = Computer(**body.model_dump(), created_by=user.username, created_at=now, updated_at=now)
    res = await db.computers.insert_one(comp.to_mongo())
    comp.id = str(res.inserted_id)
    return comp.model_dump()


def oid(cid: str) -> ObjectId:
    if not ObjectId.is_valid(cid):
        raise HTTPException(404, "Data tidak ditemukan")
    return ObjectId(cid)


@api.put("/computers/{cid}")
async def update_computer(cid: str, body: ComputerIn, user: User = Depends(current_user)):
    doc = await db.computers.find_one({"_id": oid(cid)})
    if not doc:
        raise HTTPException(404, "Data tidak ditemukan")
    err = await check_unique(body, cid)
    if err:
        raise HTTPException(400, err)
    update = {**body.model_dump(), "updated_at": datetime.now(timezone.utc).isoformat()}
    await db.computers.update_one({"_id": oid(cid)}, {"$set": update})
    return Computer.from_mongo(await db.computers.find_one({"_id": oid(cid)})).model_dump()


@api.delete("/computers/{cid}")
async def delete_computer(cid: str, user: User = Depends(current_user)):
    res = await db.computers.delete_one({"_id": oid(cid)})
    if not res.deleted_count:
        raise HTTPException(404, "Data tidak ditemukan")
    return {"ok": True}


def file_stamp(location: str):
    loc = location.replace(" ", "_") if location else "Semua_Lokasi"
    return f"Inventaris_Komputer_{loc}_{datetime.now(WIB).strftime('%Y%m%d_%H%M')}"


@api.get("/computers/export/excel")
async def export_excel(location: str = Query(""), q: str = Query(""), user: User = Depends(current_user)):
    data = build_xlsx(await list_computers(location, q))
    name = file_stamp(location) + ".xlsx"
    return Response(data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{name}"', "Access-Control-Expose-Headers": "Content-Disposition"})


@api.post("/computers/export/pdf")
async def export_pdf(body: PdfIn, user: User = Depends(current_user)):
    items = await list_computers(body.location, body.q)
    pdf, pages = build_pdf(items, body, public_user(user))
    name = file_stamp(body.location) + ".pdf"
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{name}"', "X-Page-Count": str(pages),
                             "X-File-Name": name, "Access-Control-Expose-Headers": "X-Page-Count, X-File-Name"})


@api.post("/computers/import")
async def import_excel(file: UploadFile = File(...), user: User = Depends(current_user)):
    if not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(400, "File harus berformat .xlsx")
    try:
        rows = parse_xlsx(await file.read())
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception:
        raise HTTPException(400, "File Excel tidak dapat dibaca")
    added, errors = 0, []
    for line, row in rows:
        try:
            item = ComputerIn(**{k: v for k, v in row.items() if k != "created_by"})
        except Exception as e:
            msg = e.errors()[0]["msg"].replace("Value error, ", "") if hasattr(e, "errors") else str(e)
            errors.append(f"Baris {line}: {msg}")
            continue
        err = await check_unique(item)
        if err:
            errors.append(f"Baris {line}: {err}")
            continue
        now = datetime.now(timezone.utc).isoformat()
        comp = Computer(**item.model_dump(), created_by=row.get("created_by") or user.username, created_at=now, updated_at=now)
        await db.computers.insert_one(comp.to_mongo())
        added += 1
    return {"added": added, "skipped": len(errors), "errors": errors[:20]}


async def seed_users():
    for entry in os.environ['SEED_USERS'].split(","):
        username, name, password = entry.split("|")
        if not await db.users.find_one({"username": username}):
            await db.users.insert_one(User(username=username, name=name, password_hash=hash_pw(password), role="admin",
                                           created_at=datetime.now(timezone.utc).isoformat()).to_mongo())
        else:
            await db.users.update_one({"username": username, "role": {"$exists": False}}, {"$set": {"role": "admin"}})


@app.on_event("startup")
async def startup():
    for coll, models in {
        "users": [IndexModel([("username", ASCENDING)], unique=True, name="username")],
        "computers": [IndexModel([("created_at", ASCENDING)], name="created_at"), IndexModel([("hostname", ASCENDING)], name="hostname"),
                      IndexModel([("mac", ASCENDING)], name="mac"), IndexModel([("sn", ASCENDING)], name="sn")],
    }.items():
        try:
            await db[coll].create_indexes(models)
        except Exception as exc:
            logger.error("index %s: %s", coll, exc)
    await seed_users()


@app.on_event("shutdown")
async def shutdown():
    client.close()


app.include_router(api)
app.add_middleware(CORSMiddleware, allow_credentials=True, allow_origins=[o.strip().rstrip('/') for o in os.environ['CORS_ORIGINS'].split(',')],
                   allow_methods=["*"], allow_headers=["*"], expose_headers=["X-Page-Count", "X-File-Name", "Content-Disposition"])
